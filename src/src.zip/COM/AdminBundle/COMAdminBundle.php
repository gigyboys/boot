<?php

namespace COM\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class COMAdminBundle extends Bundle
{
}
