<?php

namespace COM\ForumBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class COMForumBundle extends Bundle
{
}
