<?php

namespace COM\SchoolBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class COMSchoolBundle extends Bundle
{
}
