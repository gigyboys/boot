<?php

namespace COM\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse; 

use COM\PlatformBundle\Entity\Locale;
use COM\UserBundle\Entity\User;
use COM\SchoolBundle\Entity\School;
use COM\SchoolBundle\Entity\SchoolTranslate;
use COM\BlogBundle\Entity\Category;
use COM\BlogBundle\Entity\Post;
use COM\BlogBundle\Entity\PostTranslate;
use COM\AdvertBundle\Entity\AdvertCategory;
use COM\AdvertBundle\Entity\Advert;
use COM\AdvertBundle\Entity\AdvertTranslate;
use COM\PlatformBundle\Entity\PostSchool;
use COM\PlatformBundle\Entity\AdvertSchool;
use COM\ForumBundle\Entity\Topic;
use COM\PlatformBundle\Entity\Parameter;

class AdminController extends Controller
{
    
}
