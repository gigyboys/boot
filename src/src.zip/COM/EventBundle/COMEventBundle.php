<?php

namespace COM\EventBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class COMEventBundle extends Bundle
{
}
