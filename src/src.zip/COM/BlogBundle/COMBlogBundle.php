<?php

namespace COM\BlogBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class COMBlogBundle extends Bundle
{
}
