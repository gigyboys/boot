<?php

namespace COM\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class COMUserBundle extends Bundle
{
}
