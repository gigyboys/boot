<?php

namespace COM\AdvertBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class COMAdvertBundle extends Bundle
{
}
