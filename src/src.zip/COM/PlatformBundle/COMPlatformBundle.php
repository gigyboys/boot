<?php

namespace COM\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class COMPlatformBundle extends Bundle
{
}
